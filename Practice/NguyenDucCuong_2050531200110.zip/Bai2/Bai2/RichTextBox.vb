﻿Public Class RichTextBox

    Private Sub RichTextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles RichTextBox1.TextChanged
        System.Diagnostics.Process.Start("http://daotao.ute.udn.vn/")
    End Sub


End Class